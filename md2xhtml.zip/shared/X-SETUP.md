Copyright © Crane Softwrights Ltd.
[https://GitHub.com/CraneSoftwrights/board-baseball](https://GitHub.com/CraneSoftwrights/board-baseball)  
[https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/X-PLAYS.md](https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/X-SETUP.md)  
[https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/X-PLAYS.html](https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/X-SETUP.html)  

# <img alt="" src="step-1.png" style="height:60px"/> <img alt="" src="x-pitching.png" style="height:60px"/>

<img alt="" src="X-start.png" style="height:360px"/>

<img alt="" src="colours.png" style="height:120px"/> [22 x A](X-SETUP.md#22-x-a) / [2 x A, 10 x B, 10 x C](X-SETUP.md#2-x-a-10-x-b-10-x-c) / [6 x A, 8 X B, 8 x C](X-SETUP.md#6-x-a-8-x-b-8-x-c)

## 22 x A

| |A|
| :---: | :---: |
| | <img alt="" src="out0.png" style="height:45px"/> |
| | <img alt="" src="it1.png" style="height:62px"/> |
| <img alt="" src="home-icon.png" style="height:40px"/>: | <img alt="" src="h-0x.png" style="height:20px"/>
| | <img alt="" src="h-RHBS0.png" style="height:52px"/>
| | <img alt="" src="h-dugout.png" style="height:130px"/>
| <img alt="" src="visitors-icon.png" style="height:40px"/> | <img alt="" src="v-0x.png" style="height:20px"/>
| | <img alt="" src="v-BSRH0.png" style="height:52px"/>
| | <img alt="" src="v-dugout.png" style="height:130px"/>

## 2 x A, 10 x B, 10 x C

|A|B|C|
| :---: | :---: | :---:
| | <img alt="" src="visitors-icon.png" style="height:40px"/> | <img alt="" src="home-icon.png" style="height:40px"/>
| <img alt="" src="out0.png" style="height:45px"/> | <img alt="" src="v-0x.png" style="height:20px"/> | <img alt="" src="h-0x.png" style="height:20px"/>
| <img alt="" src="it1.png" style="height:62px"/> | <img alt="" src="v-BSRH0.png" style="height:52px"/> | <img alt="" src="h-RHBS0.png" style="height:52px"/>
| | <img alt="" src="v-dugout.png" style="height:130px"/> | <img alt="" src="h-dugout.png" style="height:130px"/>


## 6 x A, 8 x B, 8 x C

|A|B|C|
| :---: | :---: | :---:
| | <img alt="" src="visitors-icon.png" style="height:40px"/> | <img alt="" src="home-icon.png" style="height:40px"/>
| <img alt="" src="out0.png" style="height:45px"/> |  <img alt="" src="v-BSRH0.png" style="height:52px"/> | <img alt="" src="h-RHBS0.png" style="height:52px"/>
| <img alt="" src="it1.png" style="height:62px"/> | <img alt="" src="v-dugout.png" style="height:130px"/> | <img alt="" src="h-dugout.png" style="height:130px"/>
| <img alt="" src="v-0x.png" style="height:20px"/> | | | 
| <img alt="" src="h-0x.png" style="height:20px"/> | | |
