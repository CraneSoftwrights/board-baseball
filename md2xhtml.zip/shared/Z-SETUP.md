Copyright © Crane Softwrights Ltd.
[https://GitHub.com/CraneSoftwrights/board-baseball](https://GitHub.com/CraneSoftwrights/board-baseball)  
[https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/Z-SETUP.md](https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/Z-SETUP.md)  
[https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/Z-SETUP.html](https://GitHub.com/CraneSoftwrights/board-baseball/blob/main/shared/Z-SETUP.html)  

# <img alt="" src="step-1.png" style="height:60px"/> <img alt="" src="z-batting.png" style="height:60px"/>

<img alt="" src="Z-start.png" style="height:360px"/>  

<img alt="" src="colours.png" style="height:120px"/> [14 x A](Z-SETUP.md#14-x-a) / [2 x A, 6 x B, 6 x C](Z-SETUP.md#2-x-a-6-x-b-6-x-c)

## 14 x A

| |A|
| :---: | :---: |
| | <img alt="" src="out0.png" style="height:45px"/> |
| | <img alt="" src="it1.png" style="height:62px"/> |
| <img alt="" src="visitors-icon.png" style="height:40px"/> | <img alt="" src="v-R0x.png" style="height:20px"/>
| | <img alt="" src="v-R0.png" style="height:52px"/>
| | <img alt="" src="v-dugout.png" style="height:130px"/>
| <img alt="" src="home-icon.png" style="height:40px"/>: | <img alt="" src="h-R0x.png" style="height:20px"/>
| | <img alt="" src="h-R0.png" style="height:52px"/>
| | <img alt="" src="h-dugout.png" style="height:130px"/>

## 2 x A, 6 x B, 6 x C

|A|B|C|
| :---: | :---: | :---:
| | <img alt="" src="visitors-icon.png" style="height:40px"/> | <img alt="" src="home-icon.png" style="height:40px"/>
| <img alt="" src="out0.png" style="height:45px"/> | <img alt="" src="v-R0x.png" style="height:20px"/> | <img alt="" src="h-R0x.png" style="height:20px"/>
| <img alt="" src="it1.png" style="height:62px"/> | <img alt="" src="v-R0.png" style="height:52px"/> | <img alt="" src="h-R0.png" style="height:52px"/>
| | <img alt="" src="v-dugout.png" style="height:130px"/> | <img alt="" src="h-dugout.png" style="height:130px"/>


